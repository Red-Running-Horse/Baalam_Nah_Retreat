
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Leaf, Waves, Users, Mail, Phone, MapPin, Facebook, Instagram } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext.jsx';

const HomePage = () => {
  const { t } = useLanguage();
  
  const content = {
    meta: {
      title: {
        en: 'Baalam Nah - Casa del Jaguar | Eco-Retreat in the Mayan Jungle',
        es: 'Baalam Nah - Casa del Jaguar | Retiro Ecológico en la Selva Maya'
      },
      description: {
        en: 'Experience authentic eco-tourism in the heart of the Mayan jungle. Sustainable cabins, nature activities, and cultural immersion in Felipe Carrillo Puerto, Quintana Roo.',
        es: 'Experimenta el ecoturismo auténtico en el corazón de la selva maya. Cabañas sostenibles, actividades en la naturaleza e inmersión cultural en Felipe Carrillo Puerto, Quintana Roo.'
      }
    },
    hero: {
      title: 'Baalam Nah - Casa del Jaguar',
      tagline: {
        en: 'Where the Jaguar Roams Free',
        es: 'Donde el Jaguar Vaga Libre'
      },
      cta: {
        en: 'Book Your Stay',
        es: 'Reserva tu Estadía'
      }
    },
    mission: {
      heading: {
        en: 'Our Mission',
        es: 'Nuestra Misión'
      },
      text: {
        en: 'Nestled in the heart of the Mayan jungle, Baalam Nah offers an authentic eco-tourism experience. We are committed to sustainable practices that honor the land and the ancient Mayan culture, providing our guests with a transformative connection to nature.',
        es: 'Ubicado en el corazón de la selva maya, Baalam Nah ofrece una experiencia auténtica de ecoturismo. Estamos comprometidos con prácticas sostenibles que honran la tierra y la antigua cultura maya, brindando a nuestros huéspedes una conexión transformadora con la naturaleza.'
      }
    },
    features: [
      {
        id: 'cabins',
        icon: Leaf,
        title: {
          en: 'Eco Cabins',
          es: 'Cabañas Ecológicas'
        },
        description: {
          en: 'Rustic cabins built with sustainable materials, offering comfort while minimizing environmental impact. Each cabin provides an intimate retreat surrounded by jungle sounds.',
          es: 'Cabañas rústicas construidas con materiales sostenibles, que ofrecen comodidad mientras minimizan el impacto ambiental. Cada cabaña proporciona un refugio íntimo rodeado de sonidos de la selva.'
        },
        image: 'https://images.unsplash.com/photo-1686195005205-82cb998eb64b'
      },
      {
        id: 'activities',
        icon: Waves,
        title: {
          en: 'Nature Activities',
          es: 'Actividades en la Naturaleza'
        },
        description: {
          en: 'Explore the jungle through kayaking, guided hikes, and bird watching. Discover hidden cenotes and observe wildlife in their natural habitat.',
          es: 'Explora la selva a través de kayak, caminatas guiadas y observación de aves. Descubre cenotes ocultos y observa la vida silvestre en su hábitat natural.'
        }
      },
      {
        id: 'culture',
        icon: Users,
        title: {
          en: 'Authentic Mayan Culture',
          es: 'Cultura Maya Auténtica'
        },
        description: {
          en: 'Immerse yourself in Mayan traditions through cultural workshops, traditional cuisine, and storytelling sessions with local community members.',
          es: 'Sumérgete en las tradiciones mayas a través de talleres culturales, cocina tradicional y sesiones de narración con miembros de la comunidad local.'
        }
      }
    ],
    footer: {
      tagline: {
        en: 'Experience the jungle. Honor the culture.',
        es: 'Experimenta la selva. Honra la cultura.'
      },
      location: 'Felipe Carrillo Puerto, Quintana Roo, México',
      email: 'info@baalamnah.com',
      phone: '+52 983 123 4567',
      privacy: {
        en: 'Privacy Policy',
        es: 'Política de Privacidad'
      },
      terms: {
        en: 'Terms of Service',
        es: 'Términos de Servicio'
      },
      rights: {
        en: 'All rights reserved.',
        es: 'Todos los derechos reservados.'
      }
    }
  };
  
  return (
    <>
      <Helmet>
        <title>{t(content.meta.title)}</title>
        <meta name="description" content={t(content.meta.description)} />
      </Helmet>
      
      <main>
        <section 
          id="hero" 
          className="relative min-h-screen flex items-center justify-center"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1642939522738-289ec8fb1bcb)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed'
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
          
          <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 
                className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight"
                style={{ letterSpacing: '-0.02em' }}
              >
                {content.hero.title}
              </h1>
              <p className="text-xl md:text-2xl text-white/90 mb-12 max-w-2xl mx-auto leading-relaxed">
                {t(content.hero.tagline)}
              </p>
              <Button 
                size="lg" 
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg px-8 py-6 transition-all duration-200 active:scale-[0.98] shadow-lg shadow-primary/20"
              >
                {t(content.hero.cta)}
              </Button>
            </motion.div>
          </div>
        </section>
        
        <section id="mission" className="py-20 md:py-24 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-6 leading-snug">
                {t(content.mission.heading)}
              </h2>
              <p className="text-lg text-foreground/80 leading-relaxed max-w-prose mx-auto">
                {t(content.mission.text)}
              </p>
            </motion.div>
          </div>
        </section>
        
        <section id="features" className="py-20 md:py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {content.features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={feature.id}
                    id={feature.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card 
                      className={`h-full transition-all duration-300 ${
                        index === 0 
                          ? 'shadow-lg hover:shadow-xl border' 
                          : index === 1 
                          ? 'bg-muted hover:bg-muted/80 border-0' 
                          : 'border-2 shadow-sm hover:shadow-md'
                      }`}
                    >
                      <CardHeader>
                        {feature.image ? (
                          <div className="mb-4 rounded-xl overflow-hidden">
                            <img 
                              src={feature.image} 
                              alt={t(feature.title)}
                              className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105"
                            />
                          </div>
                        ) : (
                          <div className="mb-4 flex items-center justify-center w-16 h-16 rounded-xl bg-primary/10">
                            <Icon className="h-8 w-8 text-primary" />
                          </div>
                        )}
                        <CardTitle className="text-2xl font-semibold">
                          {t(feature.title)}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-base leading-relaxed">
                          {t(feature.description)}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
        
        <footer id="contact" className="bg-foreground text-background py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
              <div>
                <h3 className="text-2xl font-bold text-primary mb-4">
                  Baalam Nah
                </h3>
                <p className="text-background/80 leading-relaxed">
                  {t(content.footer.tagline)}
                </p>
              </div>
              
              <div>
                <span className="text-lg font-semibold mb-4 block">
                  {t({ en: 'Contact', es: 'Contacto' })}
                </span>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-background/80 text-sm">
                      {content.footer.location}
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-primary flex-shrink-0" />
                    <a 
                      href={`mailto:${content.footer.email}`}
                      className="text-background/80 text-sm hover:text-primary transition-colors duration-200"
                    >
                      {content.footer.email}
                    </a>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                    <a 
                      href={`tel:${content.footer.phone}`}
                      className="text-background/80 text-sm hover:text-primary transition-colors duration-200"
                    >
                      {content.footer.phone}
                    </a>
                  </div>
                </div>
              </div>
              
              <div>
                <span className="text-lg font-semibold mb-4 block">
                  {t({ en: 'Follow Us', es: 'Síguenos' })}
                </span>
                <div className="flex space-x-4">
                  <a 
                    href="#" 
                    className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center hover:bg-primary/20 transition-all duration-200 active:scale-95"
                    aria-label="Facebook"
                  >
                    <Facebook className="h-5 w-5 text-primary" />
                  </a>
                  <a 
                    href="#" 
                    className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center hover:bg-primary/20 transition-all duration-200 active:scale-95"
                    aria-label="Instagram"
                  >
                    <Instagram className="h-5 w-5 text-primary" />
                  </a>
                </div>
              </div>
            </div>
            
            <div className="pt-8 border-t border-background/20 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <p className="text-background/60 text-sm">
                © 2026 Baalam Nah. {t(content.footer.rights)}
              </p>
              <div className="flex space-x-6">
                <a 
                  href="#" 
                  className="text-background/60 text-sm hover:text-primary transition-colors duration-200"
                >
                  {t(content.footer.privacy)}
                </a>
                <a 
                  href="#" 
                  className="text-background/60 text-sm hover:text-primary transition-colors duration-200"
                >
                  {t(content.footer.terms)}
                </a>
              </div>
            </div>
          </div>
        </footer>
      </main>
    </>
  );
};

export default HomePage;
